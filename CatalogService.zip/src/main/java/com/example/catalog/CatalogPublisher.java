package com.example.catalog;

import jakarta.xml.ws.Endpoint;

public class CatalogPublisher {

    public static void main(String[] args) {
        Endpoint.publish("http://localhost:8080/catalog", new CatalogServiceImpl());
        System.out.println("Catalog service is published at http://localhost:8080/catalog");
    }
}
