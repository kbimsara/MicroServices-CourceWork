package com.example.catalog;

import jakarta.jws.WebService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebService(endpointInterface = "com.example.catalog.CatalogService")
public class CatalogServiceImpl implements CatalogService {

    private Map<String, Product> products = new HashMap<>();

    @Override
    public List<Product> getAllProducts() {
        return new ArrayList<>(products.values());
    }

    @Override
    public Product getProduct(String id) {
        return products.get(id);
    }

    @Override
    public Product createProduct(Product product) {
        products.put(product.getId(), product);
        return product;
    }

    @Override
    public Product updateProduct(String id, Product product) {
        products.put(id, product);
        return product;
    }

    @Override
    public void deleteProduct(String id) {
        products.remove(id);
    }
}
