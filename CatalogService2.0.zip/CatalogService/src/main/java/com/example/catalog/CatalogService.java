package com.example.catalog;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import java.util.List;

@WebService
public interface CatalogService {

    @WebMethod
    List<Product> getAllProducts();

    @WebMethod
    Product getProduct(String id);

    @WebMethod
    Product createProduct(Product product);

    @WebMethod
    Product updateProduct(String id, Product product);

    @WebMethod
    void deleteProduct(String id);
}
